Readme:

1)Install hadoop cluster ,configar and run it
2)Apache spark is installed, up and running.
3)The input file that needs to be sorted is already present on the server or HDFS, and the path to this file has been updated in the Python script.
4)A path for the output file has been created in the server or HDFS, and this path has been updated in the Python script. The output file has been successfully generated and can be found in the specified path. A sample of the output is being displayed and the output data is stored in CSV file.

