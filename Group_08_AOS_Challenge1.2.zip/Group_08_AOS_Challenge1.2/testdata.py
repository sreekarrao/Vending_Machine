import csv
import urllib.request

url = 'https://www2.cs.uic.edu/~brents/cs494-cdcs/data/export'
response = urllib.request.urlopen(url)
data = response.read().decode('utf-8').splitlines()
xyz = [row.split(',') for row in data[1:]]
sort_data = sorted(xyz, key=lambda row: (row[2], row[-1]))

with open('Output.csv', 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerows(sort_data)

print("Top 5 Rows:")
for row in sort_data[:5]:
    print(','.join(row))

print("\nBottom 5 Rows:")
for row in sort_data[-5:]:
    print(','.join(row))